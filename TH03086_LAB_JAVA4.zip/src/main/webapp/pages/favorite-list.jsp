<%@ page pageEncoding="utf-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Danh sách yêu thích tổng hợp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4 rounded">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">PolyOE Admin</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="${pageContext.request.contextPath}/user/crud/index">Quản lý User</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="${pageContext.request.contextPath}/favorite/list">Tất cả Video Yêu Thích</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <h2 class="mb-4">Danh sách video đã được yêu thích</h2>

    <table class="table table-bordered table-striped shadow-sm">
        <thead class="table-dark">
            <tr>
                <th>Video Title</th>
                <th>Người thích</th>
                <th>Ngày thích</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach var="f" items="${favorites}">
                <tr>
                    <td class="fw-bold text-primary">${f.video.title}</td>
                    <td>${f.user.fullname}</td>
                    <td><fmt:formatDate value="${f.likeDate}" pattern="dd/MM/yyyy"/></td>
                </tr>
            </c:forEach>
            <c:if test="${empty favorites}">
                <tr>
                    <td colspan="3" class="text-center">Chưa có dữ liệu yêu thích nào.</td>
                </tr>
            </c:if>
        </tbody>
    </table>
</body>
</html>
