<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Java 4</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-4 card p-4 shadow-sm border-0">
                <h3 class="text-center mb-4">ĐĂNG NHẬP</h3>

                <c:if test="${not empty error}">
                    <div class="alert alert-danger py-2 small">${error}</div>
                </c:if>

                <form action="${pageContext.request.contextPath}/login" method="post">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">ID hoặc Email:</label>
                        <input name="usernameOrEmail" class="form-control" placeholder="Nhập ID/Email..." required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Mật khẩu:</label>
                        <input name="password" type="password" class="form-control" placeholder="Nhập mật khẩu..." required>
                    </div>
                    <button class="btn btn-primary w-100 fw-bold">Đăng nhập</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
