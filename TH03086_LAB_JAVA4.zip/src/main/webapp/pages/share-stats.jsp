<%@ page pageEncoding="utf-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<!DOCTYPE html>
<html>
<head>
    <title>Share Stats</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <h3 class="mb-4">Thông tin chia sẻ tổng hợp</h3>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Tiêu đề video</th>
                <th>Số lượt chia sẻ</th>
                <th>Ngày chia sẻ đầu tiên</th>
                <th>Ngày chia sẻ cuối cùng</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach var="row" items="${stats}">
                <tr>
                    <td>${row[0]}</td>
                    <td>${row[1]}</td>
                    <td><fmt:formatDate value="${row[2]}" pattern="dd/MM/yyyy"/></td>
                    <td><fmt:formatDate value="${row[3]}" pattern="dd/MM/yyyy"/></td>
                </tr>
            </c:forEach>
        </tbody>
    </table>
</body>
</html>
