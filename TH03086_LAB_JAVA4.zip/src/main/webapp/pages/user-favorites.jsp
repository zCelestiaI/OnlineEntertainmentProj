<%@ page pageEncoding="utf-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Favorite Videos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white text-uppercase">
            <h2 class="mb-0">${user.fullname}</h2>
        </div>
        <div class="card-body">
            <h4 class="text-secondary border-bottom pb-2">CÁC VIDEO ĐÃ YÊU THÍCH</h4>

            <c:if test="${not empty user.favorites}">
                <ul class="list-group list-group-flush mt-3">
                    <c:forEach var="favorite" items="${user.favorites}">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <i class="bi bi-play-circle-fill text-danger me-2"></i>
                                <span class="fw-bold text-dark">${favorite.video.title}</span>
                                <small class="text-muted ms-3">(Ngày thích: ${favorite.likeDate})</small>
                            </div>
                            <span class="badge bg-info rounded-pill">${favorite.video.views} lượt xem</span>
                        </li>
                    </c:forEach>
                </ul>
            </c:if>

            <c:if test="${empty user.favorites}">
                <div class="alert alert-warning mt-3">
                    Người dùng này chưa yêu thích video nào.
                </div>
            </c:if>
        </div>
        <div class="card-footer">
            <a href="${pageContext.request.contextPath}/user/crud/index" class="btn btn-outline-secondary">
                Quay lại quản lý User
            </a>
        </div>
    </div>
</body>
</html>
