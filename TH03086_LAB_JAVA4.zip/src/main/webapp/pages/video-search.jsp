<%@ page pageEncoding="utf-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Video Search - User Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .custom-search { border: 1px solid #ffcc80; width: 400px; }
    </style>
</head>
<body class="container mt-4">
    <nav class="navbar navbar-expand-lg navbar-light bg-light mb-4 rounded border">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold text-primary" href="#">PolyVideo</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link active" href="${pageContext.request.contextPath}/video/search">Tìm kiếm</a></li>
                    <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/user/favorites?userId=${currentUser.id}">Yêu thích của tôi</a></li>
                </ul>
                <div class="d-flex align-items-center">
                    <span class="me-3 text-secondary">Chào, <strong>${currentUser.fullname}</strong></span>
                    <a href="${pageContext.request.contextPath}/login" class="btn btn-outline-danger btn-sm">Đăng xuất</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="mb-4 d-flex align-items-center">
        <label class="me-3 fw-bold">Từ khóa</label>
        <form action="${pageContext.request.contextPath}/video/search" method="get">
            <input name="keyword" class="form-control custom-search d-inline" value="${param.keyword}" placeholder="Nhập tên video...">
        </form>
    </div>

    <hr>
    <h5>Kết quả tìm kiếm:</h5>
    <div class="row mt-3">
        <c:forEach var="v" items="${videos}">
            <div class="col-md-4 mb-3">
                <div class="card shadow-sm h-100">
                    <div class="card-body">
                        <h6 class="card-title fw-bold">${v.title}</h6>
                        <p class="text-muted small">${v.description}</p>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <span class="badge bg-info">${v.favorites.size()} lượt thích</span>
                            <button class="btn btn-sm btn-outline-danger">❤ Thích</button>
                        </div>
                    </div>
                </div>
            </c:forEach>
            <c:if test="${empty videos && not empty param.keyword}">
                <div class="alert alert-warning">Không tìm thấy video nào phù hợp!</div>
            </c:if>
        </div>
    </div>
</body>
</html>
