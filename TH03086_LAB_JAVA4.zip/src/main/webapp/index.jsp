<% response.sendRedirect(request.getContextPath() + "/user/crud/index"); %>
