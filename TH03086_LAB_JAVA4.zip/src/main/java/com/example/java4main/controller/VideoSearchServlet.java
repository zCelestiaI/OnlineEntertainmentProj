package com.example.java4main.controller;

import com.example.java4main.dao.VideoDAO;
import com.example.java4main.dao.VideoDAOImpl;
import com.example.java4main.entity.Video;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

@WebServlet("/video/search")
public class VideoSearchServlet extends HttpServlet {
    private VideoDAO dao = new VideoDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String keyword = req.getParameter("keyword");
        if (keyword != null) {
            List<Video> results = dao.findByTitle(keyword);
            req.setAttribute("videos", results);
        }
        req.getRequestDispatcher("/pages/video-search.jsp").forward(req, resp);
    }
}
