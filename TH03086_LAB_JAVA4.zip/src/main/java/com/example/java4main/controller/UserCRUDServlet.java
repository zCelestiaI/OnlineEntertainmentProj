package com.example.java4main.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;
import com.example.java4main.dao.UserDAO;
import com.example.java4main.dao.UserDAOImpl;
import com.example.java4main.entity.User;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

@WebServlet({
        "/user/crud/index",
        "/user/crud/edit/*",
        "/user/crud/create",
        "/user/crud/update",
        "/user/crud/delete",
        "/user/crud/reset"})
public class UserCRUDServlet extends HttpServlet {
    
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        UserDAO dao = new UserDAOImpl();
        User form = new User();
        
        try {
            BeanUtils.populate(form, req.getParameterMap());
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }

        String message = "Enter user information";
        String path = req.getServletPath();

        if (path.contains("edit")) {
            String id = req.getPathInfo().substring(1);
            form = dao.findById(id);
            message = "Editing User: " + id;
        } else if (path.contains("create")) {
            try {
                dao.create(form);
                message = "User created successfully!";
                form = new User();
            } catch (Exception e) {
                message = "Error creating user!";
            }
        } else if (path.contains("update")) {
            try {
                dao.update(form);
                message = "User updated successfully!";
            } catch (Exception e) {
                message = "Error updating user!";
            }
        } else if (path.contains("delete")) {
            try {
                dao.deleteById(form.getId());
                message = "User deleted successfully!";
                form = new User();
            } catch (Exception e) {
                message = "Error deleting user!";
            }
        } else if (path.contains("reset")) {
            form = new User();
        }

        // Tích hợp yêu cầu tìm kiếm và phân trang (Kết quả in ra Console)
        dao.findByEmailAndRole("@fpt.edu.vn", false);
        dao.findPage(2, 5); // Trang 3 (index = 2), kích thước 5

        req.setAttribute("message", message);
        req.setAttribute("user", form);
        req.setAttribute("users", dao.findAll());
        req.getRequestDispatcher("/pages/user-crud.jsp").forward(req, resp);
    }
}
