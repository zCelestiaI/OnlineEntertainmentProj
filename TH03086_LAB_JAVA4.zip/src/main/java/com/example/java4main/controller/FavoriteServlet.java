package com.example.java4main.controller;

import com.example.java4main.dao.UserDAO;
import com.example.java4main.dao.UserDAOImpl;
import com.example.java4main.entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/user/favorites")
public class FavoriteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userId = req.getParameter("userId");
        if (userId == null || userId.isEmpty()) {
            userId = "U01"; // Mặc định hiển thị cho Nguyễn Văn An theo data mẫu
        }

        UserDAO dao = new UserDAOImpl();
        User user = dao.findById(userId);

        req.setAttribute("user", user);
        req.getRequestDispatcher("/pages/user-favorites.jsp").forward(req, resp);
    }
}
