package com.example.java4main.controller;

import com.example.java4main.dao.UserDAO;
import com.example.java4main.dao.UserDAOImpl;
import com.example.java4main.entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private UserDAO dao = new UserDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/pages/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String uoe = req.getParameter("usernameOrEmail");
        String pass = req.getParameter("password");
        
        User user = dao.findByIdOrEmail(uoe);
        
        if (user != null && user.getPassword().equals(pass)) {
            req.getSession().setAttribute("currentUser", user);
            
            // Phân quyền điều hướng
            if (user.isAdmin()) {
                // Admin vào trang quản trị (CRUD User/Video)
                resp.sendRedirect(req.getContextPath() + "/user/crud/index");
            } else {
                // User vào trang giải trí (Search/Favorites)
                resp.sendRedirect(req.getContextPath() + "/video/search");
            }
        } else {
            req.setAttribute("error", "Invalid ID/Email or Password!");
            req.getRequestDispatcher("/pages/login.jsp").forward(req, resp);
        }
    }
}
