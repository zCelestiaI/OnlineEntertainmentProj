package com.example.java4main.controller;

import java.io.*;
import java.util.List;

import com.example.java4main.entity.User;
import com.example.java4main.service.UserService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet("/list-user")
public class UserServlet extends HttpServlet {
    private final UserService userService = new UserService();

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<User> users = userService.findAll();
        request.setAttribute("users", users);
        // Forward to index.jsp to display the table
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }
}
