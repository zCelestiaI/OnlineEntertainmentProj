package com.example.java4main.controller;

import com.example.java4main.dao.VideoDAO;
import com.example.java4main.dao.VideoDAOImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

@WebServlet("/video/share-stats")
public class ShareStatsServlet extends HttpServlet {
    private VideoDAO dao = new VideoDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Object[]> stats = dao.getShareStats();
        req.setAttribute("stats", stats);
        req.getRequestDispatcher("/pages/share-stats.jsp").forward(req, resp);
    }
}
