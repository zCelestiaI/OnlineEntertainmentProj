package com.example.java4main.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "Users")
public class User {
    @Id
    @Column(name = "Id", length = 20)
    private String id;

    @Column(name = "Password", length = 50)
    private String password;

    @Column(name = "Fullname", length = 50)
    private String fullname;

    @Column(name = "Email", length = 50, unique = true)
    private String email;

    @Column(name = "Admin")
    private boolean admin;

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    private List<Favorite> favorites;

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    private List<Share> shares;
}
