package com.example.java4main.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "Video")
public class Video {
    @Id
    @Column(name = "Id", length = 20)
    private String id;

    @Column(name = "Title", length = 255)
    private String title;

    @Column(name = "Poster", length = 255)
    private String poster;

    @Column(name = "Views")
    private Integer views = 0;

    @Column(name = "Description")
    private String description;

    @Column(name = "Active")
    private boolean active = true;

    @OneToMany(mappedBy = "video", fetch = FetchType.LAZY)
    private List<Favorite> favorites;

    @OneToMany(mappedBy = "video", fetch = FetchType.LAZY)
    private List<Share> shares;
}
