package com.example.java4main.filter;

import com.example.java4main.entity.User;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebFilter({"/user/crud/*", "/video/share-stats"})
public class AuthFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        HttpSession session = req.getSession();
        
        User user = (User) session.getAttribute("currentUser");
        
        if (user == null) {
            // Chưa đăng nhập
            resp.sendRedirect(req.getContextPath() + "/login");
        } else if (!user.isAdmin()) {
            // Đã đăng nhập nhưng không phải Admin
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Bạn không có quyền truy cập chức năng này!");
        } else {
            // Là Admin, cho phép đi tiếp
            chain.doFilter(request, response);
        }
    }
}
