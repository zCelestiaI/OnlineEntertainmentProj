package com.example.java4main.dao;

import com.example.java4main.entity.Video;
import java.util.List;

public interface VideoDAO {
    List<Video> findByTitle(String keyword);
    List<Video> findTop10Favorites();
    List<Video> findNotLiked();
    List<Video> findSharedInYear(int year);
    List<Object[]> getShareStats();
}
