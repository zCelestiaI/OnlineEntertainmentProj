package com.example.java4main.dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;
import com.example.java4main.entity.User;
import com.example.java4main.utils.XJPA;

import java.util.List;

public class UserDAOImpl implements UserDAO {
    private EntityManager em = XJPA.getEntityManager();

    @Override
    protected void finalize() throws Throwable {
        if (em != null && em.isOpen()) {
            em.close();
        }
        super.finalize();
    }

    @Override
    public List<User> findAll() {
        String jpql = "SELECT o FROM User o";
        TypedQuery<User> query = em.createQuery(jpql, User.class);
        return query.getResultList();
    }

    @Override
    public User findById(String id) {
        return em.find(User.class, id);
    }

    @Override
    public void create(User entity) {
        try {
            em.getTransaction().begin();
            em.persist(entity);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw e;
        }
    }

    @Override
    public void update(User entity) {
        try {
            em.getTransaction().begin();
            em.merge(entity);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw e;
        }
    }

    @Override
    public void deleteById(String id) {
        User entity = em.find(User.class, id);
        try {
            em.getTransaction().begin();
            if (entity != null) {
                em.remove(entity);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw e;
        }
    }

    @Override
    public List<User> findByEmailAndRole(String emailSuffix, boolean isAdmin) {
        String jpql = "SELECT o FROM User o WHERE o.email LIKE :search AND o.admin = :role";
        TypedQuery<User> query = em.createQuery(jpql, User.class);
        query.setParameter("search", "%" + emailSuffix);
        query.setParameter("role", isAdmin);
        return query.getResultList();
    }

    @Override
    public List<User> findPage(int pageNumber, int pageSize) {
        String jpql = "SELECT o FROM User o";
        TypedQuery<User> query = em.createQuery(jpql, User.class);
        query.setFirstResult(pageNumber * pageSize);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }

    @Override
    public User findByIdOrEmail(String usernameOrEmail) {
        String jpql = "SELECT o FROM User o WHERE o.id = :uoe OR o.email = :uoe";
        TypedQuery<User> query = em.createQuery(jpql, User.class);
        query.setParameter("uoe", usernameOrEmail);
        try {
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public long count() {
        String jpql = "SELECT count(o) FROM User o";
        TypedQuery<Long> query = em.createQuery(jpql, Long.class);
        return query.getSingleResult();
    }
}
