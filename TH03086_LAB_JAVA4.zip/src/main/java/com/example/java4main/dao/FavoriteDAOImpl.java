package com.example.java4main.dao;

import com.example.java4main.entity.Favorite;
import com.example.java4main.utils.XJPA;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

public class FavoriteDAOImpl implements FavoriteDAO {
    @Override
    public List<Favorite> findAll() {
        EntityManager em = XJPA.getEntityManager();
        try {
            String jpql = "SELECT f FROM Favorite f";
            TypedQuery<Favorite> query = em.createQuery(jpql, Favorite.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }
}
