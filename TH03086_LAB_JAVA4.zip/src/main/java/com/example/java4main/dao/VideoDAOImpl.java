package com.example.java4main.dao;

import com.example.java4main.entity.Video;
import com.example.java4main.utils.XJPA;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

public class VideoDAOImpl implements VideoDAO {
    private EntityManager em = XJPA.getEntityManager();

    @Override
    public List<Video> findByTitle(String keyword) {
        String jpql = "SELECT v FROM Video v WHERE v.title LIKE :kw";
        TypedQuery<Video> query = em.createQuery(jpql, Video.class);
        query.setParameter("kw", "%" + keyword + "%");
        return query.getResultList();
    }

    @Override
    public List<Video> findTop10Favorites() {
        String jpql = "SELECT v FROM Video v WHERE v.favorites IS NOT EMPTY ORDER BY size(v.favorites) DESC";
        TypedQuery<Video> query = em.createQuery(jpql, Video.class);
        query.setMaxResults(10);
        return query.getResultList();
    }

    @Override
    public List<Video> findNotLiked() {
        String jpql = "SELECT v FROM Video v WHERE v.favorites IS EMPTY";
        return em.createQuery(jpql, Video.class).getResultList();
    }

    @Override
    public List<Video> findSharedInYear(int year) {
        String jpql = "SELECT DISTINCT v FROM Video v JOIN v.shares s WHERE YEAR(s.shareDate) = :year ORDER BY s.shareDate";
        TypedQuery<Video> query = em.createQuery(jpql, Video.class);
        query.setParameter("year", year);
        return query.getResultList();
    }

    @Override
    public List<Object[]> getShareStats() {
        String jpql = "SELECT s.video.title, COUNT(s.id), MIN(s.shareDate), MAX(s.shareDate) " +
                      "FROM Share s GROUP BY s.video.title";
        return em.createQuery(jpql, Object[].class).getResultList();
    }
}
