package com.example.java4main.dao;

import com.example.java4main.entity.Favorite;
import java.util.List;

public interface FavoriteDAO {
    List<Favorite> findAll();
}
