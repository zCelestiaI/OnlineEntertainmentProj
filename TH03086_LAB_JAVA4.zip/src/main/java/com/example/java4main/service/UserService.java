package com.example.java4main.service;

import com.example.java4main.dao.UserDAO;
import com.example.java4main.dao.UserDAOImpl;
import com.example.java4main.entity.User;

import java.util.List;

public class UserService {
    private final UserDAO userDAO;

    public UserService() {
        // Fix: Interface cannot be instantiated directly, use UserDAOImpl
        this.userDAO = new UserDAOImpl();
    }

    public List<User> findAll() {
        return userDAO.findAll();
    }

    public User findById(String id) {
        return userDAO.findById(id);
    }

    public void create(User user) {
        userDAO.create(user);
    }

    public void update(User user) {
        userDAO.update(user);
    }

    public void deleteById(String id) {
        userDAO.deleteById(id);
    }
}
