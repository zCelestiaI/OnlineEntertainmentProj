package com.example.java4main.dao;

import com.example.java4main.entity.User;
import java.util.List;

public interface UserDAO {
    List<User> findAll();
    User findById(String id);
    void create(User item);
    void update(User item);
    void deleteById(String id);
    List<User> findByEmailAndRole(String emailSuffix, boolean isAdmin);
    List<User> findPage(int pageNumber, int pageSize);
}
