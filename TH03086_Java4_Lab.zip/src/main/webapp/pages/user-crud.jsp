<%@ page pageEncoding="utf-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Lab Java 4</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <div class="alert alert-info">
        <i>${message}</i>
    </div>

    <c:url var="url" value="/user/crud"/>
    <form method="post" class="card p-3 mb-4">
        <div class="mb-2">
            <label class="form-label">Id:</label>
            <input name="id" class="form-control" value="${user.id}">
        </div>
        <div class="mb-2">
            <label class="form-label">Password:</label>
            <input name="password" type="password" class="form-control" value="${user.password}">
        </div>
        <div class="mb-2">
            <label class="form-label">Fullname:</label>
            <input name="fullname" class="form-control" value="${user.fullname}">
        </div>
        <div class="mb-2">
            <label class="form-label">Email:</label>
            <input name="email" class="form-control" value="${user.email}">
        </div>
        <div class="mb-3">
            <label class="form-label">Role:</label><br>
            <div class="form-check form-check-inline">
                <input name="admin" class="form-check-input" type="radio" value="true" ${user.admin ? 'checked' : ''}>
                <label class="form-check-label">Admin</label>
            </div>
            <div class="form-check form-check-inline">
                <input name="admin" class="form-check-input" type="radio" value="false" ${user.admin ? '' : 'checked'}>
                <label class="form-check-label">User</label>
            </div>
        </div>
        <div class="btn-group">
            <button class="btn btn-primary" formaction="${url}/create">Create</button>
            <button class="btn btn-warning" formaction="${url}/update">Update</button>
            <button class="btn btn-danger" formaction="${url}/delete">Delete</button>
            <button class="btn btn-secondary" formaction="${url}/reset">Reset</button>
        </div>
    </form>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Id</th>
                <th>Password</th>
                <th>Fullname</th>
                <th>Email</th>
                <th>Role</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach var="u" items="${users}">
                <tr>
                    <td>${u.id}</td>
                    <td>${u.password}</td>
                    <td>${u.fullname}</td>
                    <td>${u.email}</td>
                    <td>${u.admin ? 'Admin' : 'User'}</td>
                    <td><a href="${url}/edit/${u.id}" class="btn btn-sm btn-info">Edit</a></td>
                </tr>
            </c:forEach>
        </tbody>
    </table>
</body>
</html>
