<%@ page contentType="text/html;charset=UTF-8" language="java"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<jsp:include page="/views/layout/header.jsp"/>
<jsp:include page="/views/layout/menu.jsp"/>

<div class="container mt-4">

    <div class="row">

        <!-- FORM -->

        <div class="col-lg-4">

            <div class="card">

                <div class="card-header">
                    <h4>Video Information</h4>
                </div>

                <div class="card-body">

                    <form action="${pageContext.request.contextPath}/admin/video"
                          method="post"
                          enctype="multipart/form-data">

                        <input type="hidden"
                               name="action"
                               value="${video == null ? 'create' : 'update'}">

                        <div class="mb-3">

                            <label>ID</label>

                            <input class="form-control"
                                   name="id"
                                   value="${video.id}"
                            ${video!=null?'readonly':''}
                                   required>

                        </div>

                        <div class="mb-3">

                            <label>Title</label>

                            <input class="form-control"
                                   name="title"
                                   value="${video.title}"
                                   required>

                        </div>

                        <div class="mb-3">

                            <label>Description</label>

                            <textarea
                                    class="form-control"
                                    rows="5"
                                    name="description">${video.description}</textarea>

                        </div>

                        <div class="mb-3">

                            <label>Poster</label>

                            <input type="file"
                                   class="form-control"
                                   name="poster">

                        </div>

                        <c:if test="${video!=null && video.poster!=null}">

                            <div class="mb-3 text-center">

                                <img
                                        src="${pageContext.request.contextPath}/assets/images/${video.poster}"
                                        class="img-thumbnail"
                                        width="180">

                            </div>

                        </c:if>

                        <div class="mb-3">

                            <label>Status</label>

                            <select class="form-select"
                                    name="active">

                                <option value="true"
                                ${video==null || video.active ? "selected":""}>
                                    Active
                                </option>

                                <option value="false"
                                ${video!=null && !video.active ? "selected":""}>
                                    Inactive
                                </option>

                            </select>

                        </div>

                        <button class="btn btn-success">

                            ${video==null?"Create":"Update"}

                        </button>

                        <a href="${pageContext.request.contextPath}/admin/video"
                           class="btn btn-secondary">

                            Reset

                        </a>

                    </form>

                </div>

            </div>

        </div>

        <!-- TABLE -->

        <div class="col-lg-8">

            <div class="card">

                <div class="card-header">

                    <h4>Video List</h4>

                </div>

                <div class="card-body">

                    <table class="table table-bordered table-hover align-middle">

                        <thead class="table-dark">

                        <tr>

                            <th>ID</th>
                            <th>Poster</th>
                            <th>Title</th>
                            <th>Views</th>
                            <th>Status</th>
                            <th width="170">Action</th>

                        </tr>

                        </thead>

                        <tbody>

                        <c:forEach items="${videos}" var="v">

                            <tr>

                                <td>${v.id}</td>

                                <td>

                                    <img
                                            src="${pageContext.request.contextPath}/assets/images/${v.poster}"
                                            width="100">

                                </td>

                                <td>${v.title}</td>

                                <td>${v.views}</td>

                                <td>

                                    <c:choose>

                                        <c:when test="${v.active}">

                                            <span class="badge bg-success">
                                                Active
                                            </span>

                                        </c:when>

                                        <c:otherwise>

                                            <span class="badge bg-danger">
                                                Inactive
                                            </span>

                                        </c:otherwise>

                                    </c:choose>

                                </td>

                                <td>

                                    <a href="${pageContext.request.contextPath}/admin/video?id=${v.id}"
                                       class="btn btn-warning btn-sm">

                                        Edit

                                    </a>

                                    <form action="${pageContext.request.contextPath}/admin/video"
                                          method="post"
                                          style="display:inline">

                                        <input type="hidden"
                                               name="action"
                                               value="delete">

                                        <input type="hidden"
                                               name="id"
                                               value="${v.id}">

                                        <button class="btn btn-danger btn-sm"
                                                onclick="return confirm('Delete this video?')">

                                            Delete

                                        </button>

                                    </form>

                                </td>

                            </tr>

                        </c:forEach>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>

</div>

<jsp:include page="/views/layout/footer.jsp"/>