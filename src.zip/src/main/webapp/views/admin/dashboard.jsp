<%@ page contentType="text/html;charset=UTF-8" language="java"%>

<jsp:include page="/views/layout/header.jsp"/>
<jsp:include page="/views/layout/menu.jsp"/>

<div class="container mt-4">

    <h2 class="mb-4">

        Admin Dashboard

    </h2>

    <div class="row">

        <div class="col-md-3">

            <div class="card text-center shadow">

                <div class="card-body">

                    <h5>Total Users</h5>

                    <h2>${users.size()}</h2>

                </div>

            </div>

        </div>

        <div class="col-md-3">

            <div class="card text-center shadow">

                <div class="card-body">

                    <h5>Total Videos</h5>

                    <h2>${videos.size()}</h2>

                </div>

            </div>

        </div>

        <div class="col-md-6">

            <div class="card shadow">

                <div class="card-body">

                    <a href="${pageContext.request.contextPath}/admin/user"
                       class="btn btn-primary me-2">

                        User Management

                    </a>

                    <a href="${pageContext.request.contextPath}/admin/video"
                       class="btn btn-success me-2">

                        Video Management

                    </a>

                    <a href="${pageContext.request.contextPath}/admin/report"
                       class="btn btn-warning">

                        Reports

                    </a>

                </div>

            </div>

        </div>

    </div>

</div>

<jsp:include page="/views/layout/footer.jsp"/>