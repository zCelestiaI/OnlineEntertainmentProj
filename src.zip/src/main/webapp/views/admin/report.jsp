<%@ page contentType="text/html;charset=UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<jsp:include page="/views/layout/header.jsp"/>
<jsp:include page="/views/layout/menu.jsp"/>

<div class="container mt-4">

    <h2>Report Management</h2>

    <ul class="nav nav-tabs mt-4">

        <li class="nav-item">
            <button class="nav-link active"
                    data-bs-toggle="tab"
                    data-bs-target="#favorite">

                Favorite Statistics

            </button>
        </li>

        <li class="nav-item">
            <button class="nav-link"
                    data-bs-toggle="tab"
                    data-bs-target="#favoriteUser">

                Favorite Users

            </button>
        </li>

        <li class="nav-item">
            <button class="nav-link"
                    data-bs-toggle="tab"
                    data-bs-target="#share">

                Shared Friends

            </button>
        </li>

    </ul>

    <div class="tab-content mt-3">

        <!-- TAB 1 -->

        <div class="tab-pane fade show active"
             id="favorite">

            <table class="table table-bordered">

                <thead class="table-dark">

                <tr>

                    <th>Video</th>
                    <th>Favorites</th>
                    <th>Newest</th>
                    <th>Oldest</th>

                </tr>

                </thead>

                <tbody>

                <c:forEach items="${favoriteStats}" var="r">

                    <tr>

                        <td>${r.title}</td>

                        <td>${r.favoriteCount}</td>

                        <td>${r.newestDate}</td>

                        <td>${r.oldestDate}</td>

                    </tr>

                </c:forEach>

                </tbody>

            </table>

        </div>

        <!-- TAB 2 -->

        <div class="tab-pane fade"
             id="favoriteUser">

            <form method="get"
                  action="${pageContext.request.contextPath}/admin/report">

                <div class="input-group mb-3">

                    <input type="text"
                           name="videoId"
                           class="form-control"
                           placeholder="Video ID">

                    <button class="btn btn-primary">

                        Search

                    </button>

                </div>

            </form>

            <table class="table table-bordered">

                <thead class="table-success">

                <tr>

                    <th>User</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Like Date</th>

                </tr>

                </thead>

                <tbody>

                <c:forEach items="${favoriteUsers}" var="f">

                    <tr>

                        <td>${f.user.id}</td>

                        <td>${f.user.fullname}</td>

                        <td>${f.user.email}</td>

                        <td>${f.likeDate}</td>

                    </tr>

                </c:forEach>

                </tbody>

            </table>

        </div>

        <!-- TAB 3 -->

        <div class="tab-pane fade"
             id="share">

            <table class="table table-bordered">

                <thead class="table-warning">

                <tr>

                    <th>User</th>
                    <th>Email</th>
                    <th>Share Date</th>

                </tr>

                </thead>

                <tbody>

                <c:forEach items="${shareUsers}" var="s">

                    <tr>

                        <td>${s.user.fullname}</td>

                        <td>${s.emails}</td>

                        <td>${s.shareDate}</td>

                    </tr>

                </c:forEach>

                </tbody>

            </table>

        </div>

    </div>

</div>

<jsp:include page="/views/layout/footer.jsp"/>