<%@ page contentType="text/html;charset=UTF-8" language="java"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<jsp:include page="/views/layout/header.jsp"/>
<jsp:include page="/views/layout/menu.jsp"/>

<div class="container mt-4">

    <h2>User Management</h2>

    <table class="table table-bordered table-hover mt-3">

        <thead class="table-dark">

        <tr>

            <th>ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Role</th>

        </tr>

        </thead>

        <tbody>

        <c:forEach items="${users}" var="u">

            <tr>

                <td>${u.id}</td>

                <td>${u.fullname}</td>

                <td>${u.email}</td>

                <td>

                    <c:choose>

                        <c:when test="${u.admin}">
                            Admin
                        </c:when>

                        <c:otherwise>
                            User
                        </c:otherwise>

                    </c:choose>

                </td>

            </tr>

        </c:forEach>

        </tbody>

    </table>

</div>

<jsp:include page="/views/layout/footer.jsp"/>