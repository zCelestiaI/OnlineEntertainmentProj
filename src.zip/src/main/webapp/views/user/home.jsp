<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<jsp:include page="/views/layout/header.jsp"/>
<jsp:include page="/views/layout/menu.jsp"/>

<div class="container mt-4">

    <div class="row">

        <c:forEach items="${videos}" var="video">

            <div class="col-md-3 mb-4">

                <div class="card h-100">

                    <img src="${pageContext.request.contextPath}/assets/images/${video.poster}"
                         class="card-img-top">

                    <div class="card-body">

                        <h5>${video.title}</h5>

                        <p>

                                ${video.views}
                            views

                        </p>

                        <a class="btn btn-primary w-100"
                           href="${pageContext.request.contextPath}/video?id=${video.id}">

                            Watch

                        </a>

                    </div>

                </div>

            </div>

        </c:forEach>

    </div>

</div>

<jsp:include page="/views/layout/footer.jsp"/>