<%@ page contentType="text/html;charset=UTF-8" language="java"%>

<jsp:include page="/views/layout/header.jsp"/>
<jsp:include page="/views/layout/menu.jsp"/>

<div class="container mt-5">

    <div class="row justify-content-center">

        <div class="col-md-5">

            <div class="card shadow">

                <div class="card-header">

                    <h3>

                        Change Password

                    </h3>

                </div>

                <div class="card-body">

                    <form method="post"
                          action="${pageContext.request.contextPath}/change-password">

                        <div class="mb-3">

                            <label>Old Password</label>

                            <input
                                    type="password"
                                    name="oldPassword"
                                    class="form-control"
                                    required>

                        </div>

                        <div class="mb-3">

                            <label>New Password</label>

                            <input
                                    type="password"
                                    name="newPassword"
                                    class="form-control"
                                    required>

                        </div>

                        <button class="btn btn-success w-100">

                            Save

                        </button>

                    </form>

                    <div class="text-danger mt-3">

                        ${message}

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<jsp:include page="/views/layout/footer.jsp"/>