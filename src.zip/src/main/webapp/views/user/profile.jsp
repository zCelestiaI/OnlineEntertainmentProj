<%@ page contentType="text/html;charset=UTF-8" language="java"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<jsp:include page="/views/layout/header.jsp"/>
<jsp:include page="/views/layout/menu.jsp"/>

<div class="container mt-4">

    <div class="card shadow">

        <div class="card-header">

            <h3>My Profile</h3>

        </div>

        <div class="card-body">

            <table class="table">

                <tr>
                    <th>User ID</th>
                    <td>${sessionScope.user.id}</td>
                </tr>

                <tr>
                    <th>Full Name</th>
                    <td>${sessionScope.user.fullname}</td>
                </tr>

                <tr>
                    <th>Email</th>
                    <td>${sessionScope.user.email}</td>
                </tr>

                <tr>
                    <th>Role</th>
                    <td>

                        <c:choose>

                            <c:when test="${sessionScope.user.admin}">
                                Admin
                            </c:when>

                            <c:otherwise>
                                User
                            </c:otherwise>

                        </c:choose>

                    </td>

                </tr>

            </table>

            <a href="${pageContext.request.contextPath}/change-password"
               class="btn btn-warning">

                Change Password

            </a>

        </div>

    </div>

</div>

<jsp:include page="/views/layout/footer.jsp"/>