<%@ page contentType="text/html;charset=UTF-8" language="java"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<jsp:include page="/views/layout/header.jsp"/>
<jsp:include page="/views/layout/menu.jsp"/>

<div class="container mt-4">

    <h3 class="mb-4">

        My Favorite Videos

    </h3>

    <div class="row">

        <c:forEach items="${favorites}" var="item">

            <div class="col-md-3 mb-4">

                <div class="card">

                    <img
                            src="${pageContext.request.contextPath}/assets/images/${item.video.poster}"
                            class="card-img-top">

                    <div class="card-body">

                        <h5>

                                ${item.video.title}

                        </h5>

                        <a
                                href="${pageContext.request.contextPath}/video?id=${item.video.id}"
                                class="btn btn-primary w-100">

                            Watch

                        </a>

                    </div>

                </div>

            </div>

        </c:forEach>

    </div>

</div>

<jsp:include page="/views/layout/footer.jsp"/>