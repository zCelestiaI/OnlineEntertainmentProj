<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<jsp:include page="/views/layout/header.jsp"/>
<jsp:include page="/views/layout/menu.jsp"/>

<div class="container mt-4">

    <div class="row">

        <div class="col-md-8">

            <img
                    src="${pageContext.request.contextPath}/assets/images/${video.poster}"
                    class="img-fluid rounded">

        </div>

        <div class="col-md-4">

            <h2>

                ${video.title}

            </h2>

            <hr>

            <p>

                ${video.description}

            </p>

            <p>

                <b>Views:</b>

                ${video.views}

            </p>

            <c:if test="${sessionScope.user!=null}">

                <form method="post"
                      action="${pageContext.request.contextPath}/favorite">

                    <input
                            type="hidden"
                            name="videoId"
                            value="${video.id}">

                    <input
                            type="hidden"
                            name="action"
                            value="like">

                    <button class="btn btn-danger w-100 mb-2">

                        ❤ Favorite

                    </button>

                </form>

                <form method="post"
                      action="${pageContext.request.contextPath}/share">

                    <input
                            type="hidden"
                            name="videoId"
                            value="${video.id}">

                    <input
                            type="email"
                            name="email"
                            placeholder="Friend's Email"
                            class="form-control mb-2"
                            required>

                    <button class="btn btn-primary w-100">

                        Share

                    </button>

                </form>

            </c:if>

        </div>

    </div>

</div>

<jsp:include page="/views/layout/footer.jsp"/>