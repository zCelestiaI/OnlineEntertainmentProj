<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">

    <div class="container">

        <a class="navbar-brand"
           href="${pageContext.request.contextPath}/home">
            Online Entertainment
        </a>

        <button class="navbar-toggler"
                data-bs-toggle="collapse"
                data-bs-target="#navbar">

            <span class="navbar-toggler-icon"></span>

        </button>

        <div class="collapse navbar-collapse"
             id="navbar">

            <ul class="navbar-nav me-auto">

                <li class="nav-item">
                    <a class="nav-link"
                       href="${pageContext.request.contextPath}/home">
                        Home
                    </a>
                </li>

                <c:if test="${sessionScope.user!=null}">

                    <li class="nav-item">
                        <a class="nav-link"
                           href="${pageContext.request.contextPath}/profile">
                            Profile
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link"
                           href="${pageContext.request.contextPath}/favorite">
                            Favorite
                        </a>
                    </li>

                </c:if>

            </ul>

            <ul class="navbar-nav">

                <c:choose>

                    <c:when test="${sessionScope.user==null}">

                        <li class="nav-item">

                            <a class="nav-link"
                               href="${pageContext.request.contextPath}/login">
                                Login
                            </a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link"
                               href="${pageContext.request.contextPath}/register">
                                Register
                            </a>

                        </li>

                    </c:when>

                    <c:otherwise>

                        <li class="nav-item">

                            <span class="navbar-text me-3">

                                Hello,
                                ${sessionScope.user.fullname}

                            </span>

                        </li>

                        <c:if test="${sessionScope.user.admin}">

                            <li class="nav-item">

                                <a class="nav-link"
                                   href="${pageContext.request.contextPath}/admin">

                                    Admin

                                </a>

                            </li>

                        </c:if>

                        <li class="nav-item">

                            <a class="nav-link"
                               href="${pageContext.request.contextPath}/logout">

                                Logout

                            </a>

                        </li>

                    </c:otherwise>

                </c:choose>

            </ul>

        </div>

    </div>

</nav>