package com.example.java4main.service;

import com.example.java4main.dao.FavoriteDAO;
import com.example.java4main.dao.impl.FavoriteDAOImpl;
import com.example.java4main.entity.Favorite;

import java.util.List;

public class FavoriteService {

    private final FavoriteDAO favoriteDAO = new FavoriteDAOImpl();

    public List<Favorite> findAll() {
        return favoriteDAO.findAll();
    }

    public Favorite findById(Long id) {
        return favoriteDAO.findById(id);
    }

    public List<Favorite> findByUser(String userId) {
        return favoriteDAO.findByUser(userId);
    }

    public List<Favorite> findByVideo(String videoId) {
        return favoriteDAO.findByVideo(videoId);
    }

    public Favorite findByUserAndVideo(String userId, String videoId) {
        return favoriteDAO.findByUserAndVideo(userId, videoId);
    }

    public Favorite create(Favorite favorite) {
        return favoriteDAO.create(favorite);
    }

    public Favorite update(Favorite favorite) {
        return favoriteDAO.update(favorite);
    }

    public void delete(Long id) {
        favoriteDAO.delete(id);
    }
}