package com.example.java4main.dto;

public class FavoriteReportDTO {

    private String title;
    private Long favoriteCount;
    private java.util.Date newestDate;
    private java.util.Date oldestDate;

    public FavoriteReportDTO() {
    }

    public FavoriteReportDTO(String title, Long favoriteCount,
                             java.util.Date newestDate,
                             java.util.Date oldestDate) {
        this.title = title;
        this.favoriteCount = favoriteCount;
        this.newestDate = newestDate;
        this.oldestDate = oldestDate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getFavoriteCount() {
        return favoriteCount;
    }

    public void setFavoriteCount(Long favoriteCount) {
        this.favoriteCount = favoriteCount;
    }

    public java.util.Date getNewestDate() {
        return newestDate;
    }

    public void setNewestDate(java.util.Date newestDate) {
        this.newestDate = newestDate;
    }

    public java.util.Date getOldestDate() {
        return oldestDate;
    }

    public void setOldestDate(java.util.Date oldestDate) {
        this.oldestDate = oldestDate;
    }
}