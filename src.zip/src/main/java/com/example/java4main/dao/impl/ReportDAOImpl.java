package com.example.java4main.dao.impl;

import com.example.java4main.dao.ReportDAO;
import com.example.java4main.dto.FavoriteReportDTO;
import com.example.java4main.entity.Favorite;
import com.example.java4main.entity.Share;
import com.example.java4main.utils.XJPA;
import jakarta.persistence.EntityManager;

import java.util.ArrayList;
import java.util.List;

public class ReportDAOImpl implements ReportDAO {

    @Override
    public List<FavoriteReportDTO> favoriteReport() {

        EntityManager em = XJPA.getEntityManager();

        try {

            String jpql =
                    "SELECT f.video.title, COUNT(f), MAX(f.likeDate), MIN(f.likeDate) " +
                            "FROM Favorite f " +
                            "GROUP BY f.video.title";

            List<Object[]> list = em.createQuery(jpql, Object[].class)
                    .getResultList();

            List<FavoriteReportDTO> result = new ArrayList<>();

            for (Object[] row : list) {

                FavoriteReportDTO dto = new FavoriteReportDTO();

                dto.setTitle((String) row[0]);
                dto.setFavoriteCount((Long) row[1]);
                dto.setNewestDate((java.util.Date) row[2]);
                dto.setOldestDate((java.util.Date) row[3]);

                result.add(dto);
            }

            return result;

        } finally {
            em.close();
        }
    }

    @Override
    public List<Favorite> favoriteUsers(String videoId) {

        EntityManager em = XJPA.getEntityManager();

        try {

            String jpql =
                    "SELECT f FROM Favorite f " +
                            "WHERE f.video.id = :id";

            return em.createQuery(jpql, Favorite.class)
                    .setParameter("id", videoId)
                    .getResultList();

        } finally {
            em.close();
        }
    }

    @Override
    public List<Share> shareUsers(String videoId) {

        EntityManager em = XJPA.getEntityManager();

        try {

            String jpql =
                    "SELECT s FROM Share s " +
                            "WHERE s.video.id = :id";

            return em.createQuery(jpql, Share.class)
                    .setParameter("id", videoId)
                    .getResultList();

        } finally {
            em.close();
        }
    }
}