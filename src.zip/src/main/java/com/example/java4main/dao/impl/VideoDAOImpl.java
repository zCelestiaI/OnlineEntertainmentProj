package com.example.java4main.dao.impl;

import com.example.java4main.dao.VideoDAO;
import com.example.java4main.entity.Video;
import com.example.java4main.utils.XJPA;
import jakarta.persistence.EntityManager;

import java.util.List;

public class VideoDAOImpl extends AbstractDAO<Video, String> implements VideoDAO {

    @Override
    public List<Video> findActive() {
        EntityManager em = XJPA.getEntityManager();

        try {
            String jpql = "SELECT v FROM Video v WHERE v.active = true";

            return em.createQuery(jpql, Video.class)
                    .getResultList();

        } finally {
            em.close();
        }
    }

    @Override
    public List<Video> search(String keyword) {
        EntityManager em = XJPA.getEntityManager();

        try {
            String jpql = "SELECT v FROM Video v WHERE LOWER(v.title) LIKE LOWER(:keyword)";

            return em.createQuery(jpql, Video.class)
                    .setParameter("keyword", "%" + keyword + "%")
                    .getResultList();

        } finally {
            em.close();
        }
    }
}