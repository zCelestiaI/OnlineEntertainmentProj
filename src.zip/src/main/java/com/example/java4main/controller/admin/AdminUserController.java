package com.example.java4main.controller.admin;

import com.example.java4main.entity.User;
import com.example.java4main.service.UserService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/admin/user")
public class AdminUserController extends HttpServlet {

    private final UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        request.setAttribute("users", userService.findAll());

        request.getRequestDispatcher("/views/admin/user.jsp")
                .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("create".equals(action)) {

            User user = new User();
            user.setId(request.getParameter("id"));
            user.setPassword(request.getParameter("password"));
            user.setFullname(request.getParameter("fullname"));
            user.setEmail(request.getParameter("email"));
            user.setAdmin(Boolean.parseBoolean(request.getParameter("admin")));

            userService.create(user);

        } else if ("update".equals(action)) {

            User user = userService.findById(request.getParameter("id"));

            user.setPassword(request.getParameter("password"));
            user.setFullname(request.getParameter("fullname"));
            user.setEmail(request.getParameter("email"));
            user.setAdmin(Boolean.parseBoolean(request.getParameter("admin")));

            userService.update(user);

        } else if ("delete".equals(action)) {

            userService.delete(request.getParameter("id"));
        }

        response.sendRedirect(request.getContextPath() + "/admin/user");
    }
}