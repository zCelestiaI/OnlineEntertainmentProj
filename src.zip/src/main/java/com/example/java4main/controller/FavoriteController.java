package com.example.java4main.controller;

import com.example.java4main.entity.Favorite;
import com.example.java4main.entity.User;
import com.example.java4main.entity.Video;
import com.example.java4main.service.FavoriteService;
import com.example.java4main.service.VideoService;
import com.example.java4main.utils.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.Date;

@WebServlet("/favorite")
public class FavoriteController extends HttpServlet {

    private final FavoriteService favoriteService = new FavoriteService();
    private final VideoService videoService = new VideoService();

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        String videoId = request.getParameter("videoId");

        User user = (User) SessionUtil.get(request, "user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        if ("like".equals(action)) {

            Favorite favorite = favoriteService.findByUserAndVideo(user.getId(), videoId);

            if (favorite == null) {
                Video video = videoService.findById(videoId);

                favorite = new Favorite();
                favorite.setUser(user);
                favorite.setVideo(video);
                favorite.setLikeDate(new Date());

                favoriteService.create(favorite);
            }

        } else if ("unlike".equals(action)) {

            Favorite favorite = favoriteService.findByUserAndVideo(user.getId(), videoId);

            if (favorite != null) {
                favoriteService.delete(favorite.getId());
            }
        }

        response.sendRedirect(request.getContextPath() + "/video?id=" + videoId);
    }
}