package com.example.java4main.controller.admin;

import com.example.java4main.service.ReportService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/admin/report")
public class ReportController extends HttpServlet {

    private final ReportService reportService = new ReportService();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        String videoId = request.getParameter("videoId");

        request.setAttribute("favoriteStats",
                reportService.favoriteReport());

        if (videoId != null && !videoId.isBlank()) {

            request.setAttribute("favoriteUsers",
                    reportService.favoriteUsers(videoId));

            request.setAttribute("shareUsers",
                    reportService.shareUsers(videoId));

        }

        request.getRequestDispatcher("/views/admin/report.jsp")
                .forward(request, response);
    }
}