package com.example.java4main.controller;

import com.example.java4main.entity.Share;
import com.example.java4main.entity.User;
import com.example.java4main.entity.Video;
import com.example.java4main.service.ShareService;
import com.example.java4main.service.VideoService;
import com.example.java4main.utils.EmailUtil;
import com.example.java4main.utils.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.Date;

@WebServlet("/share")
public class ShareController extends HttpServlet {

    private final ShareService shareService = new ShareService();
    private final VideoService videoService = new VideoService();

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        User user = (User) SessionUtil.get(request, "user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String videoId = request.getParameter("videoId");
        String email = request.getParameter("email");

        Video video = videoService.findById(videoId);

        Share share = new Share();
        share.setUser(user);
        share.setVideo(video);
        share.setEmails(email);
        share.setShareDate(new Date());

        shareService.create(share);

        EmailUtil.send(
                email,
                "Video Sharing",
                "https://youtube.com/watch?v=" + videoId
        );

        response.sendRedirect(request.getContextPath() + "/video?id=" + videoId);
    }
}