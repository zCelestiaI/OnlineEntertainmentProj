package com.example.java4main.controller;

import com.example.java4main.entity.User;
import com.example.java4main.service.FavoriteService;
import com.example.java4main.utils.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/profile")
public class ProfileController extends HttpServlet {

    private final FavoriteService favoriteService = new FavoriteService();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        User user = (User) SessionUtil.get(request, "user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        request.setAttribute("favorites",
                favoriteService.findByUser(user.getId()));

        request.getRequestDispatcher("/views/profile.jsp")
                .forward(request, response);
    }
}