package com.example.java4main.controller;

import com.example.java4main.entity.User;
import com.example.java4main.service.UserService;
import com.example.java4main.utils.EmailUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/forgot-password")
public class ForgotPasswordController extends HttpServlet {

    private final UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        request.getRequestDispatcher("/views/forgot-password.jsp")
                .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");

        User user = userService.findByEmail(email);

        if (user == null) {
            request.setAttribute("message", "Email không tồn tại.");
            request.getRequestDispatcher("/views/forgot-password.jsp")
                    .forward(request, response);
            return;
        }

        EmailUtil.send(
                user.getEmail(),
                "Forgot Password",
                "Mật khẩu của bạn là: " + user.getPassword()
        );

        request.setAttribute("message", "Đã gửi mật khẩu về email.");
        request.getRequestDispatcher("/views/forgot-password.jsp")
                .forward(request, response);
    }
}