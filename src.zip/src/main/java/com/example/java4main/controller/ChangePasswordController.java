package com.example.java4main.controller;

import com.example.java4main.entity.User;
import com.example.java4main.service.UserService;
import com.example.java4main.utils.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/change-password")
public class ChangePasswordController extends HttpServlet {

    private final UserService userService = new UserService();

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        User user = (User) SessionUtil.get(request, "user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String oldPassword = request.getParameter("oldPassword");
        String newPassword = request.getParameter("newPassword");

        if (!user.getPassword().equals(oldPassword)) {
            request.setAttribute("message", "Mật khẩu cũ không đúng.");
            request.getRequestDispatcher("/views/change-password.jsp")
                    .forward(request, response);
            return;
        }

        user.setPassword(newPassword);
        userService.update(user);

        SessionUtil.set(request, "user", user);

        response.sendRedirect(request.getContextPath() + "/profile");
    }
}