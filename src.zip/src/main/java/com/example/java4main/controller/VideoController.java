package com.example.java4main.controller;

import com.example.java4main.entity.Video;
import com.example.java4main.service.VideoService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/video")
public class VideoController extends HttpServlet {

    private final VideoService videoService = new VideoService();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");

        if (id == null || id.isBlank()) {
            response.sendRedirect(request.getContextPath() + "/home");
            return;
        }

        Video video = videoService.findById(id);

        if (video == null) {
            response.sendRedirect(request.getContextPath() + "/home");
            return;
        }

        request.setAttribute("video", video);

        request.getRequestDispatcher("/views/detail.jsp")
                .forward(request, response);
    }
}