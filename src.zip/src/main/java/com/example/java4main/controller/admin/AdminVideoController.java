package com.example.java4main.controller.admin;

import com.example.java4main.entity.Video;
import com.example.java4main.service.VideoService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.File;
import java.io.IOException;

@WebServlet("/admin/video")
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024,
        maxFileSize = 1024 * 1024 * 10,
        maxRequestSize = 1024 * 1024 * 20
)
public class AdminVideoController extends HttpServlet {

    private final VideoService videoService = new VideoService();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");

        if (id != null && !id.isBlank()) {
            request.setAttribute("video", videoService.findById(id));
        }

        request.setAttribute("videos", videoService.findAll());

        request.getRequestDispatcher("/views/admin/video.jsp")
                .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");

        switch (action) {

            case "create":
                createVideo(request);
                break;

            case "update":
                updateVideo(request);
                break;

            case "delete":
                deleteVideo(request);
                break;
        }

        response.sendRedirect(request.getContextPath() + "/admin/video");
    }

    private void createVideo(HttpServletRequest request)
            throws IOException, ServletException {

        Video video = new Video();

        video.setId(request.getParameter("id"));
        video.setTitle(request.getParameter("title"));
        video.setDescription(request.getParameter("description"));
        video.setViews(0);
        video.setActive(Boolean.parseBoolean(request.getParameter("active")));

        Part part = request.getPart("poster");

        if (part != null && part.getSize() > 0) {

            String fileName = savePoster(part);

            video.setPoster(fileName);

        } else {

            video.setPoster("default.jpg");

        }

        videoService.create(video);
    }

    private void updateVideo(HttpServletRequest request)
            throws IOException, ServletException {

        Video video = videoService.findById(request.getParameter("id"));

        if (video == null) return;

        video.setTitle(request.getParameter("title"));
        video.setDescription(request.getParameter("description"));
        video.setActive(Boolean.parseBoolean(request.getParameter("active")));

        Part part = request.getPart("poster");

        if (part != null && part.getSize() > 0) {

            String fileName = savePoster(part);

            video.setPoster(fileName);
        }

        videoService.update(video);
    }

    private void deleteVideo(HttpServletRequest request) {

        String id = request.getParameter("id");

        if (id != null && !id.isBlank()) {

            videoService.delete(id);

        }

    }

    private String savePoster(Part part)
            throws IOException {

        String fileName = new File(part.getSubmittedFileName()).getName();

        String uploadPath = getServletContext()
                .getRealPath("/assets/images");

        File folder = new File(uploadPath);

        if (!folder.exists()) {
            folder.mkdirs();
        }

        part.write(uploadPath + File.separator + fileName);

        return fileName;
    }
}